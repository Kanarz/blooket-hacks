# Support discord server: https://discord.gg/TV8sYbe4RY

# blook-rush

This cheat only works in blook rush gamemode!

# setBlooks.js

### Get the script from the file [setBlooks.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/blook-rush/setBlooks.js)

# setDefense.js

### Get the script from the file [setDefense.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/blook-rush/setDefense.js)
