# Support discord server: https://discord.gg/TV8sYbe4RY

# deceptive-dinos

This cheat only works in crazy deceptive dinos gamemode!

# fossilMultiplier.js

### Get the script from the file [fossilMultiplier.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/deceptive-dinos/fossilMultiplier.js)

# getFossils.js

### Get the script from the file [getFossils.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/deceptive-dinos/getFossils.js)v
