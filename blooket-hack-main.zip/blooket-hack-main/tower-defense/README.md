# Support discord server: https://discord.gg/TV8sYbe4RY

# tower-defense

This cheat only works in tower defense game mode!

# changeGameRound.js

### Get the script from the file [changeGameRound.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/tower-defense/changeGameRound.js) or https://schoolcheats.net/blooket


# clearEnemies.js

### Get the script from the file [clearEnemies.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/tower-defense/clearEnemies.js) or https://schoolcheats.net/blooket


# getCash.js

### Get the script from the file [getCash.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/tower-defense/getCash.js) or https://schoolcheats.net/blooket

# maxOutTowerStats.js

### Get the script from the file [getCash.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/tower-defense/maxOutTowerStats.js)
