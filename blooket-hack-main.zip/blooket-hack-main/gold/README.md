# Support discord server: https://discord.gg/TV8sYbe4RY

# gold

This cheat only works in gold game mode!

# chestESP.js

### Get the script from the file [chestESP.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/gold/chestESP.js) or https://schoolcheats.net/blooket

# getGold.js

### Get the script from the file [getGold.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/gold/getGold.js) or https://schoolcheats.net/blooket
