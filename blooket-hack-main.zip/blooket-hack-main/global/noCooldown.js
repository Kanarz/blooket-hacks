javascript:setTimeout=function(f,t){f()};
