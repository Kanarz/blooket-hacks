# Support discord server: https://discord.gg/TV8sYbe4RY

# crazy-kingdom

This cheat only works in crazy kingdom gamemode!

# choiceESP.js

### Get the script from the file [choiceESP.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/crazy-kingdom/choiceESP.js) or https://schoolcheats.net/blooket

# maxResources.js

### Get the script from the file [maxResources.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/crazy-kingdom/maxResources.js) or https://schoolcheats.net/blooket

# noTaxes.js

### Get the script from the file [noTaxes.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/crazy-kingdom/noTaxes.js) or https://schoolcheats.net/blooket

# setGuests.js

### Get the script from the file [setGuests.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/crazy-kingdom/setGuests.js) or https://schoolcheats.net/blooket

# skipGuests.js

### Get the script from the file [skipGuests.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/crazy-kingdom/skipGuests.js) or https://schoolcheats.net/blooket
