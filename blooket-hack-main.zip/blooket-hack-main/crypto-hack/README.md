# Support discord server: https://discord.gg/TV8sYbe4RY

# crypto-hack

This cheat only works in crazy crypto-hack gamemode!

# getCrypto.js

### Get the script from the file [getCrypto.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/crypto-hack/getCrypto.js) or https://schoolcheats.net/blooket

# getOtherUsersPassword.js

### Get the script from the file [getOtherUsersPassword.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/crypto-hack/getOtherUsersPassword.js) or https://schoolcheats.net/blooket
