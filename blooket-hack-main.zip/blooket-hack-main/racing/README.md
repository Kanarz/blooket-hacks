# Support discord server: https://discord.gg/TV8sYbe4RY

# racing 

This cheat only works in racing game mode!

# instantWin.js

### Get the script from the file [instantWin.js](https://raw.githubusercontent.com/glixxzzy/blooket-hack/main/racing/instantWin.js) or https://schoolcheats.net/blooket
